$(function () {
  $('.example-popover').popover({
    container: 'body'
  })
})